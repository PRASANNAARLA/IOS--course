//
//  ViewController.swift
//  Arla_SearchApp
//
//  Created by student on 10/12/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultImage: UIImageView!
        @IBOutlet weak var searchTextField: UITextField!
        @IBOutlet weak var topicInfoText: UITextView!
        @IBOutlet weak var showMoreImagesBtn: UIButton!
    var fullindex :Int!
    var eachindex : Int!
    var arr=[["bird1","bird2","bird3","bird4","bird5"],["fruit1","fruit2","fruit3","fruit4","fruit5"],["insect1","insect2","insect3","insect4","insect5"],["tree1","tree2","tree3","tree4","tree5"],["tulips","whiteflower","rose","redroses","sunflower"]]
    var keywords=[["bird1","bird2","bird3","bird4","bird5"],["fruit1","fruit2","fruit3","fruit4","fruit5"],["insect1","insect2","insect3","insect4","insect5"],["tree1","tree2","tree3","tree4","tree5"],["tulips","whiteflower","rose","redroses","sunflower"]]
    
    let inform = ["Birds are a group of warm-blooded vertebrates constituting the class Aves /ˈeɪviːz/, characterised by feathers, toothless beaked jaws, the laying of hard-shelled eggs, a high metabolic rate, a four-chambered heart, and a strong yet lightweight skeleton. Birds live worldwide and range in size from the 5.5 cm (2.2 in) bee hummingbird to the 2.8 m (9 ft 2 in) ostrich. There are about ten thousand living species, more than half of which are passerine, or birds. Birds have wings whose development varies according to species; the only known groups without wings are the extinct moa and elephant birds. Wings, which evolved from forelimbs, gave birds the ability to fly, although further evolution has led to the loss of flight in some birds, including ratites, penguins, and diverse endemic island species. The digestive and respiratory systems of birds are also uniquely adapted for flight. Some bird species of aquatic environments, particularly seabirds and some waterbirds, have further evolved for swimming.","Fruits are the means by which flowering plants (also known as angiosperms) disseminate their seeds. Edible fruits in particular have long propagated using the movements of humans and animals in a symbiotic relationship that is the means for seed dispersal for the one group and nutrition for the other; in fact, humans and many animals have become dependent on fruits as a source of food.[1] Consequently, fruits account for a substantial fraction of the world's agricultural output, and some (such as the apple and the pomegranate) have acquired extensive cultural and symbolic meanings.","In botany, a tree is a perennial plant with an elongated stem, or trunk, supporting branches and leaves in most species. In some usages, the definition of a tree may be narrower, including only wood plants with secondary growth, plants that are usable as lumber or plants above a specified height. In wider definitions, the taller palms, tree ferns, bananas, and bamboos are also trees. Trees are not a taxonomic group but include a variety of plant species that have independently evolved a trunk and branches as a way to tower above other plants to compete for sunlight. Trees tend to be long-lived, some reaching several thousand years old.","In botany, a tree is a perennial plant with an elongated stem, or trunk, supporting branches and leaves in most species. In some usages, the definition of a tree may be narrower, including only wood plants with secondary growth, plants that are usable as lumber or plants above a specified height. In wider definitions, the taller palms, tree ferns, bananas, and bamboos are also trees. Trees are not a taxonomic group but include a variety of plant species that have independently evolved a trunk and branches as a way to tower above other plants to compete for sunlight. Trees tend to be long-lived, some reaching several thousand years old.","A flower, sometimes known as a bloom or blossom, is the reproductive structure found in flowering plants (plants of the division Magnoliophyta, also called angiosperms). The biological function of a flower is to facilitate reproduction, usually by providing a mechanism for the union of sperm with eggs. Flowers may facilitate outcrossing (fusion of sperm and eggs from different individuals in a population) resulting from cross-pollination or allow selfing (fusion of sperm and egg from the same flower) when self-pollination occurs."]
    
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            showMoreImagesBtn.isEnabled = false
        }

    @IBAction func searchButtonAction(_ sender: UIButton) {
                        fullindex = 0
                        for images in arr {
                            if images.contains(searchTextField.text!){
                                eachindex=0
                                var name = arr[fullindex][0]
                                topicInfoText.text = inform [fullindex]
                                updatingImage(name)
                                showMoreImagesBtn.isEnabled = true
                                break;
                            }
                            fullindex += 1
                        }
                    }
                    
    @IBAction func showMoreImagesAction(_ sender: UIButton) {
                eachindex += 1
                updatingImage(arr[fullindex][eachindex])
                if eachindex == arr[fullindex].count - 1 {
                    showMoreImagesBtn.isEnabled = false
                }
            
            }
        
        func updatingImage(_ name : String){
            resultImage.image = UIImage(named: name)
        }
                }




